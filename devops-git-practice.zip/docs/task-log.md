# Task Log for DevOps Git Practice

## [feature/sample-task]
- Initialized Git repo
- Created `.gitignore`, `README.md`, and script
- Committed and pushed code
- Created PR to dev and merged

## [dev → main]
- Merged stable code from dev to main

## Tags
- v1.0: First stable release

## Tools Used
- Git
- GitHub (for PRs and repo hosting)
